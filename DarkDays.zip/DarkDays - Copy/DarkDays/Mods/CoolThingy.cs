﻿using StupidTemplate.Notifications;
using System;
using System.Collections.Generic;
using System.Text;

namespace StupidTemplate.Mods
    {
        internal class GrabAllIds
        {
            public static void GrabAllIdsMod()
            {
                string list = "==============Player Id's==============!";
                foreach (VRRig rigs in GorillaParent.instance.vrrigs)
                {
                    if (!rigs.isOfflineVRRig && !rigs.isMyPlayer)
                    {
                        list += rigs.OwningNetPlayer.NickName + " - User Id : " + rigs.OwningNetPlayer.UserId;
                    }
                }
                System.IO.Directory.CreateDirectory("//you're menu name");
                System.IO.File.AppendAllText("//you're menu nameIds.txt", list);
                NotifiLib.SendNotification("<color=grey>[</color><color=green>SUCCESSFULLY</color><color=grey>]</color> Grabbed Id's!");
            }
        }
    }


