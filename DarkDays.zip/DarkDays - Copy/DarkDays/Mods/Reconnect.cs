﻿using Photon.Pun;
using System;
using System.Collections.Generic;
using System.Text;

namespace StupidTemplate.Mods
{
    internal class Reconnect
    {
        public static void ReconnectMod()
        {
            PhotonNetwork.Reconnect();
        }

    }
}
