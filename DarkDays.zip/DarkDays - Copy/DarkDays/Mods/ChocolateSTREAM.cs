﻿using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;

namespace StupidTemplate.Mods
{
    internal class ChocolateSTREAM
    {
        public static void ChocolateSTREAMMod()
        {
            if (ControllerInputPoller.instance.rightGrab)
            {
                Vector3 startPos = GorillaTagger.Instance.rightHandTransform.position + new Vector3(0f, 0f, 0f);
                Vector3 charVel = GorillaTagger.Instance.rightHandTransform.transform.forward * 0.1f;
                int proj = 2061412059;
                int trail = -1;
                var col = new Color(0.50f, 0.35f, 0.25f);
            }
            if (ControllerInputPoller.instance.leftGrab)
            {
                Vector3 startPos = GorillaTagger.Instance.leftHandTransform.position + new Vector3(0f, 0f, 0f);
                Vector3 charVel = GorillaTagger.Instance.leftHandTransform.transform.forward * 0.1f;
                int proj = 2061412059;
                int trail = -1;
                var col = new Color(0.50f, 0.35f, 0.25f);
            }
        }
    }
}
