﻿using StupidTemplate.Notifications;
using System;
using System.Collections.Generic;
using System.Text;

namespace StupidTemplate.Mods
    {
        internal class grabids
        {
            public static void graballids()
            {
                string list = "==============Player Id's==============!";
                foreach (VRRig rigs in GorillaParent.instance.vrrigs)
                {
                    if (!rigs.isOfflineVRRig && !rigs.isMyPlayer)
                    {
                        list += rigs.OwningNetPlayer.NickName + " - User Id : " + rigs.OwningNetPlayer.UserId;
                    }
                }
                System.IO.Directory.CreateDirectory("Menu Name");
                System.IO.File.AppendAllText("MenuIds.txt", list);
                NotifiLib.SendNotification("<color=grey>[</color><color=green>SUCCESSFULLY</color><color=grey>]</color> Grabbed Everybodys Id's!");
            }
        }
    }


