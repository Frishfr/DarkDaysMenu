﻿using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;

namespace StupidTemplate.Mods
{
    internal class Test
    {
        public static void Spaz1Glider()
        {
            GameObject.Find("Environment Objects/PersistentObjects_Prefab/Gliders_Placement_Prefab/Root/LeafGliderFunctional").transform.eulerAngles += new Vector3(100f, 100f, 100f) * Time.deltaTime;
            //MADE BY @TheCrazyDepartment! PLS GIVE CREDS
        }

        //MADE BY @TheCrazyDepartment! PLS GIVE CREDS
        public static void SpazGliderz()
        {
            GameObject.Find("Environment Objects/PersistentObjects_Prefab/Gliders_Placement_Prefab/Root/LeafGliderFunctional").transform.eulerAngles += new Vector3(100f, 100f, 100f) * Time.deltaTime;
            GameObject.Find("Environment Objects/PersistentObjects_Prefab/Gliders_Placement_Prefab/Root/LeafGliderFunctional (1)").transform.eulerAngles += new Vector3(100f, 100f, 100f) * Time.deltaTime;
            GameObject.Find("Environment Objects/PersistentObjects_Prefab/Gliders_Placement_Prefab/Root/LeafGliderFunctional (4)").transform.eulerAngles += new Vector3(100f, 100f, 100f) * Time.deltaTime;
            GameObject.Find("Environment Objects/PersistentObjects_Prefab/Gliders_Placement_Prefab/Root/LeafGliderFunctional (5)").transform.eulerAngles += new Vector3(100f, 100f, 100f) * Time.deltaTime;
            GameObject.Find("Environment Objects/PersistentObjects_Prefab/Gliders_Placement_Prefab/Root/LeafGliderFunctional (7)").transform.eulerAngles += new Vector3(100f, 100f, 100f) * Time.deltaTime;
            GameObject.Find("Environment Objects/PersistentObjects_Prefab/Gliders_Placement_Prefab/Root/LeafGliderFunctional (8)").transform.eulerAngles += new Vector3(100f, 100f, 100f) * Time.deltaTime;
            GameObject.Find("Environment Objects/PersistentObjects_Prefab/Gliders_Placement_Prefab/Root/LeafGliderFunctional (9)").transform.eulerAngles += new Vector3(100f, 100f, 100f) * Time.deltaTime;
            GameObject.Find("Environment Objects/PersistentObjects_Prefab/Gliders_Placement_Prefab/Root/LeafGliderFunctional (10)").transform.eulerAngles += new Vector3(100f, 100f, 100f) * Time.deltaTime;
            GameObject.Find("Environment Objects/PersistentObjects_Prefab/Gliders_Placement_Prefab/Root/LeafGliderFunctional (11)").transform.eulerAngles += new Vector3(100f, 100f, 100f) * Time.deltaTime;
            GameObject.Find("Environment Objects/PersistentObjects_Prefab/Gliders_Placement_Prefab/Root/LeafGliderFunctional (12)").transform.eulerAngles += new Vector3(100f, 100f, 100f) * Time.deltaTime;
            GameObject.Find("Environment Objects/PersistentObjects_Prefab/Gliders_Placement_Prefab/Root/LeafGliderFunctional (17)").transform.eulerAngles += new Vector3(100f, 100f, 100f) * Time.deltaTime;
            GameObject.Find("Environment Objects/PersistentObjects_Prefab/Gliders_Placement_Prefab/Root/LeafGliderFunctional (19)").transform.eulerAngles += new Vector3(100f, 100f, 100f) * Time.deltaTime;
            GameObject.Find("Environment Objects/PersistentObjects_Prefab/Gliders_Placement_Prefab/Root/LeafGliderFunctional (20)").transform.eulerAngles += new Vector3(100f, 100f, 100f) * Time.deltaTime;
            GameObject.Find("Environment Objects/PersistentObjects_Prefab/Gliders_Placement_Prefab/Root/LeafGliderFunctional (21)").transform.eulerAngles += new Vector3(100f, 100f, 100f) * Time.deltaTime;
            GameObject.Find("Environment Objects/PersistentObjects_Prefab/Gliders_Placement_Prefab/Root/LeafGliderFunctional (23)").transform.eulerAngles += new Vector3(100f, 100f, 100f) * Time.deltaTime;
            GameObject.Find("Environment Objects/PersistentObjects_Prefab/Gliders_Placement_Prefab/Root/LeafGliderFunctional (24)").transform.eulerAngles += new Vector3(100f, 100f, 100f) * Time.deltaTime;
            //MADE BY @TheCrazyDepartment! PLS GIVE CREDS
        }

        //MADE BY @TheCrazyDepartment! PLS GIVE CREDS
        public static void SpazBug()
        {
            GameObject.Find("Floating Bug Holdable").transform.eulerAngles += new Vector3(100f, 100f, 100f) * Time.deltaTime;
            //MADE BY @TheCrazyDepartment! PLS GIVE CREDS
        }
        //MADE BY @TheCrazyDepartment! PLS GIVE CREDS
        public static void SpazBat()
        {
            GameObject.Find("Cave Bat Holdable").transform.eulerAngles += new Vector3(100f, 100f, 100f) * Time.deltaTime;
            //MADE BY @TheCrazyDepartment! PLS GIVE CREDS
        }
    }
}
