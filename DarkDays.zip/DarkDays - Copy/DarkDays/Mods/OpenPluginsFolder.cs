﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;

namespace StupidTemplate.Mods
{
    internal class OpenPluginsFolder
    {
        public static void OpenPluginsFolderMod()
        {
            string filePath = System.IO.Path.Combine(System.Reflection.Assembly.GetExecutingAssembly().Location, "iisStupidMenu/Plugins");
            filePath = filePath.Split("BepInEx\\")[0] + "iisStupidMenu/Plugins";
            Process.Start(filePath);
        }
    }
}
