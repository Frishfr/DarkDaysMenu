﻿using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;

namespace StupidTemplate.Mods
{
    internal class Dance
    {
        public static void DanceMod() //DeepSeek AI
        {
            if (GorillaTagger.Instance == null || GorillaTagger.Instance.offlineVRRig == null)
                return;

            // Calculate wave offsets using Time.time for smooth animation
            float waveOffsetY = Mathf.Sin(Time.time * 4f) * 0.3f; // Vertical arm movement
            float waveOffsetX = Mathf.Cos(Time.time * 4f) * 0.2f; // Horizontal body sway

            // Get references to the hands
            var leftHand = GorillaTagger.Instance.offlineVRRig.leftHand.rigTarget.transform;
            var rightHand = GorillaTagger.Instance.offlineVRRig.rightHand.rigTarget.transform;

            // Apply King of Egypt dance motion to the hands
            leftHand.position = GorillaTagger.Instance.offlineVRRig.transform.position +
                                GorillaTagger.Instance.offlineVRRig.transform.right * -0.5f +
                                GorillaTagger.Instance.offlineVRRig.transform.up * (1.5f + waveOffsetY);

            rightHand.position = GorillaTagger.Instance.offlineVRRig.transform.position +
                                 GorillaTagger.Instance.offlineVRRig.transform.right * 0.5f +
                                 GorillaTagger.Instance.offlineVRRig.transform.up * (1.5f + waveOffsetY);

            // Add rotation to the hands for a stiff, robotic look
            leftHand.rotation = GorillaTagger.Instance.offlineVRRig.transform.rotation *
                                Quaternion.Euler(0, 0, waveOffsetY * 20);
            rightHand.rotation = GorillaTagger.Instance.offlineVRRig.transform.rotation *
                                 Quaternion.Euler(0, 0, -waveOffsetY * 20);

            // Sway the body side to side
            GorillaTagger.Instance.offlineVRRig.transform.localRotation =
                Quaternion.Euler(0, waveOffsetX * 10, 0);
        }
    }
}
