﻿using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;

namespace StupidTemplate.Mods
{
    internal class idk
    {

        public class GunTemplate : MonoBehaviour
        {
            public GameObject gunModel; // Assign a gun model prefab in Unity
            public float shootForce = 500f;
            public float maxRange = 50f;
            public LayerMask shootableLayer;

            private GameObject gunInstance;

            private void Start()
            {
                SpawnGun();
            }

            private void SpawnGun()
            {
                if (gunModel != null)
                {
                    gunInstance = Instantiate(gunModel, transform.position, transform.rotation);
                    gunInstance.transform.SetParent(transform);
                }
            }

            private void Update()
            {
                if (Input.GetButtonDown("Fire1")) // Replacing ControllerInput with standard Unity input
                {
                    ShootGun();
                }
            }

            private void ShootGun()
            {
                Vector3 shootPosition = transform.position;
                Vector3 shootDirection = transform.forward;
                RaycastHit hit;

                if (Physics.Raycast(shootPosition, shootDirection, out hit, maxRange, shootableLayer))
                {
                    Rigidbody rb = hit.collider.GetComponent<Rigidbody>();
                    if (rb != null)
                    {
                        rb.AddForce(shootDirection * shootForce, ForceMode.Impulse);
                    }
                }
            }
        }

    }
}

