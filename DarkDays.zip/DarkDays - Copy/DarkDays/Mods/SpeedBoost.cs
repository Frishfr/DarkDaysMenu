﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StupidTemplate.Mods
{
    internal class SpeedBoost
    {
        
        public static void SpeedBoostMod()
    {    
            GorillaLocomotion.Player.Instance.jumpMultiplier = 9f;
            GorillaLocomotion.Player.Instance.maxJumpSpeed = 9f;
        }
    }
}
