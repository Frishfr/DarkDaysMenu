﻿using GorillaNetworking;
using System;
using System.Collections.Generic;
using System.Text;

namespace StupidTemplate.Mods
{
    internal class AllCosmetx
    {
        public static void AllCosmetxMod()
        {
            foreach (var cosmeticItem in CosmeticsController.instance.allCosmetics)
            {
                CosmeticsController.instance.ProcessExternalUnlock(cosmeticItem.itemName, false, false);
            }

            CosmeticsController.instance.UpdateMyCosmetics();
            CosmeticsController.instance.UpdateWardrobeModelsAndButtons();
            CosmeticsController.instance.OnCosmeticsUpdated?.Invoke();
        }
    }
}
