﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StupidTemplate.Mods
{
    class SpoofName
    {
        public static void SpoofNameMod()
        {
            string[] names = new string[]
            {
                "0",
                "1",
                "2",
                "3",
                "4",
                "5",
                "6",
                "7",
                "8",
                "9",
                "SHIBAGT",
                "PBBV",
                "J3VU",
                "BEES",
                "NAMO",
                "MANGO",
                "FROSTY",
                "FRISH",
                "LITTLETIMMY",
                "SILLYBILLY",
                "TIMMY",
                "MINIGAMES",
                "MINIGAMESKID",
                "JMANCURLY",
                "VMT",
                "ELLIOT",
                "POLAR",
                "3CLIPCE",
                "GORILLAVR",
                "GORILLAVRGT",
                "GORILLAGTVR",
                "GORILLAGT",
                "SHARKPUPPET",
                "DUCKY",
                "EDDIE",
                "EDDY",
                "RAKZZ",
                "CASEOH",
                "SKETCH",
                "WATERMELON",
                "CRAZY",
                "MONK",
                "MONKE",
                "MONKI",
                "MONKEY",
                "MONKIY",
                "GORILL",
                "GOORILA",
                "GORILLA",
                "REDBERRY",
                "FOX",
                "RUFUS",
                "TTT",
                "TTTPIG",
                "PPPTIG",
                "K9",
                "BTC",
                "TICKLETIPJR"
            };
        }
    }
}
