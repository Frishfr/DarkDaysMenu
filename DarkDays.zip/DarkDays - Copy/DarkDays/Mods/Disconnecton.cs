﻿using Photon.Pun;
using StupidTemplate.Notifications;
using System;
using System.Collections.Generic;
using System.Text;

namespace StupidTemplate.Mods
{
    internal class Disconnecton
    {
        public static void DisconnectonMod()
        {
            if (ControllerInputPoller.instance.rightControllerPrimaryButton)
            {
                PhotonNetwork.Disconnect();
                NotifiLib.SendNotification("[<color=red>NOTIFICATION</color>] SUCCESSFULLY DISCONNECTED!(i think) ");
            }
        }
    }
}
