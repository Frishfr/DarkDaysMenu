﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StupidTemplate.Mods
{
    internal class ResetArms
    {
        public static void ResetArmsMod()
        {
            GorillaLocomotion.Player.Instance.transform.localScale = new UnityEngine.Vector3(1.0f, 1.0f, 1.0f);
        }
    }
}