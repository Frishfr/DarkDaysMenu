﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StupidTemplate.Mods
{
    class GripSpeed
    {
        public static void GripSpeedMod()
        {
            if (ControllerInputPoller.instance.rightGrab)
            {
                GorillaLocomotion.Player.Instance.jumpMultiplier = 9f;
                GorillaLocomotion.Player.Instance.maxJumpSpeed = 9f;
            }
        }
    }
}
