﻿using Photon.Pun;
using System;
using System.Collections.Generic;
using System.Text;

namespace StupidTemplate.Mods
{
    internal class Joinrandom
    {
        public static void JoinrandomMod()
        {
            PhotonNetwork.JoinRandomRoom();
        }
    }
}
