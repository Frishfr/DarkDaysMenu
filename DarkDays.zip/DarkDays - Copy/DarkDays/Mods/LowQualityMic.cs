﻿using POpusCodec.Enums;
using System;
using System.Collections.Generic;
using System.Text;

namespace StupidTemplate.Mods
{
    internal class LowQualityMic
    {
        public static void LowQualityMicMod()
        {
            Photon.Voice.Unity.Recorder mic = GorillaTagger.Instance.myRecorder;
            mic.SamplingRate = SamplingRate.Sampling08000;
            //oldBitrate = mic.Bitrate;
            mic.Bitrate = 5;

            mic.RestartRecording(true);
        }
    }
}
