﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StupidTemplate.Mods
{
    internal class FixHead
    {
        public static void FixHeadMod()
        {
            GorillaTagger.Instance.offlineVRRig.head.trackingRotationOffset.x = 0f;
            GorillaTagger.Instance.offlineVRRig.head.trackingRotationOffset.y = 0f;
            GorillaTagger.Instance.offlineVRRig.head.trackingRotationOffset.z = 0f;
        }
    }
}
