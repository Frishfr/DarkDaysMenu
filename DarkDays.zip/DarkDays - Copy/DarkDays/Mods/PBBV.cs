﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StupidTemplate.Mods
{
    class PBBV
    {
        public static void PBBVMod()
        {
            GorillaLocomotion.Player.Instance.disableMovement = true;
        }

    }
}
