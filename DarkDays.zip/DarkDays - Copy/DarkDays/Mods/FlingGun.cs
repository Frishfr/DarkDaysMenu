﻿using BepInEx;
using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine.InputSystem;
using UnityEngine;
using GorillaLocomotion;

namespace StupidTemplate.Mods
{
    internal class FlingGun
    {
        private static GameObject GunSphere;

        public static void FlingGunMod()
        {
            // Check if grip is pressed and mouse button is held
            if (ControllerInputPoller.instance.rightControllerGripFloat > 0.1f || UnityInput.Current.GetMouseButton(1))
            {
                // Raycast from the right controller
                if (Physics.Raycast(Player.Instance.rightControllerTransform.position, -Player.Instance.rightControllerTransform.up, out RaycastHit hitInfo))
                {
                    // Optional: Aim with mouse if right mouse button pressed
                    if (Mouse.current.rightButton.isPressed)
                    {
                        Camera cam = GameObject.Find("Shoulder Camera").GetComponent<Camera>();
                        Ray ray = cam.ScreenPointToRay(Mouse.current.position.ReadValue());
                        Physics.Raycast(ray, out hitInfo, 100);
                    }

                    // Create a sphere at the hit point for visual feedback
                    GunSphere = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    GunSphere.transform.position = hitInfo.point;
                    GunSphere.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
                    GunSphere.GetComponent<Renderer>().material.shader = Shader.Find("GorillaTag/UberShader");
                    GunSphere.GetComponent<Renderer>().material.color = Color.white;
                    Destroy(GunSphere.GetComponent<BoxCollider>());
                    Destroy(GunSphere.GetComponent<Rigidbody>());
                    Destroy(GunSphere.GetComponent<Collider>());

                    // Check if we hit a player or object
                    VRRig player = hitInfo.collider.GetComponent<VRRig>();

                    // If trigger pressed, apply fling force
                    if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.1f || UnityInput.Current.GetMouseButton(0))
                    {
                        if (player != null)
                        {
                            // Fling player
                            Rigidbody playerRb = player.GetComponent<Rigidbody>();
                            if (playerRb != null)
                            {
                                Vector3 flingDirection = hitInfo.normal * -1; // Fling in the opposite direction
                                float flingForce = 1000f;
                                playerRb.AddForce(flingDirection * flingForce, ForceMode.Impulse);
                            }
                        }
                        else
                        {
                            // Fling generic objects
                            Rigidbody hitRb = hitInfo.collider.GetComponent<Rigidbody>();
                            if (hitRb != null)
                            {
                                Vector3 flingDirection = hitInfo.normal * -1;
                                float flingForce = 1000f;
                                hitRb.AddForce(flingDirection * flingForce, ForceMode.Impulse);
                            }
                        }
                    }

                    // Clean up the visual sphere
                    if (GunSphere != null)
                    {
                        Destroy(GunSphere, 0.5f);
                    }
                }
            }
        }

        private static void Destroy(GameObject gunSphere, float v)
        {
            throw new NotImplementedException();
        }

        private static void Destroy(Collider collider)
        {
            throw new NotImplementedException();
        }

        private static void Destroy(Rigidbody rigidbody)
        {
            throw new NotImplementedException();
        }

        private static void Destroy(BoxCollider boxCollider)
        {
            throw new NotImplementedException();
        }
    }
}
