﻿using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;

namespace StupidTemplate.Mods
{
    internal class DisableAirSwim
    {
        public static GameObject airSwimPart = null;
        public static void DisableAirSwimMod()
        {
            if (airSwimPart != null)
            {
                UnityEngine.Object.Destroy(airSwimPart);
            }
        }
    }
}
