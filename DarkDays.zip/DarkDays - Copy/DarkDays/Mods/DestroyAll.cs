﻿using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;

namespace StupidTemplate.Mods
{
    internal class DestroyAll
    {
        public static void DestroyAllMod()
        {
            foreach (VRRig player in GorillaParent.instance.vrrigs)
            {
                if (GameObject.Find("Gorilla Local Player"))
                {
                    return;
                }
                else
                {
                    player.SafeDestroy();
                }
            }
        }
    }
}

