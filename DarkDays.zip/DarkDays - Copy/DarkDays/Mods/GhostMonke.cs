﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StupidTemplate.Mods
{
    internal class GhostMonke
    {
        public static void GhostMonkeMod()
        {
            if (ControllerInputPoller.instance.rightControllerSecondaryButton)
            {
                GorillaTagger.Instance.offlineVRRig.enabled = false;
            }
            else
            {
                GorillaTagger.Instance.offlineVRRig.enabled = true;
            }
        }
    }
}
