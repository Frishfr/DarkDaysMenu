﻿using POpusCodec.Enums;
using System;
using System.Collections.Generic;
using System.Text;

namespace StupidTemplate.Mods
{
    internal class HighQualityMic
    {
        public static void HighQualityMicMod()
        {
            Photon.Voice.Unity.Recorder mic = GorillaTagger.Instance.myRecorder;
            mic.SamplingRate = SamplingRate.Sampling16000;
            mic.Bitrate = 20000;

            mic.RestartRecording(true);
        }

    }
}
