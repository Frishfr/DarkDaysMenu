﻿using GorillaLocomotion;
using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;

namespace StupidTemplate.Mods
{
    class FlickTagger
    {
        public static void FlickTaggerMod()
        {
            bool rightGrab = ControllerInputPoller.instance.rightGrab;
            if (rightGrab)
            {
                Vector3 position = Player.Instance.rightControllerTransform.position;
                Vector3 forward = Player.Instance.rightControllerTransform.forward;
                Player.Instance.rightControllerTransform.position = position + forward * 10f;
            }
            bool leftGrab = ControllerInputPoller.instance.leftGrab;
            if (leftGrab)
            {
                Vector3 position2 = Player.Instance.leftControllerTransform.position;
                Vector3 forward2 = Player.Instance.leftControllerTransform.forward;
                Player.Instance.leftControllerTransform.position = position2 + forward2 * 10f;
            }
        }
    }
}
