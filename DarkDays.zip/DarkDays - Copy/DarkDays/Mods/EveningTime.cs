﻿using System;
using System.Collections.Generic;
using System.Text;

namespace StupidTemplate.Mods
{
    internal class EveningTime
    {
        public static void EveningTimeMod()
        {
            BetterDayNightManager.instance.SetTimeOfDay(7);
        }
    }
}
