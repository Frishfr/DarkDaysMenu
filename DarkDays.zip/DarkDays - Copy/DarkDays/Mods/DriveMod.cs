﻿using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;

namespace StupidTemplate.Mods
{
    internal class DriveMod
    {
        public static void DriveModMod() // this is made by pankakes dont skid 🙂
        {
            if (ControllerInputPoller.instance.rightControllerPrimary2DAxis.y > 0.5f)
            {
                GorillaLocomotion.Player.Instance.bodyCollider.attachedRigidbody.AddForce(GorillaLocomotion.Player.Instance.bodyCollider.transform.forward * (Time.deltaTime * (15f / Time.deltaTime)), ForceMode.Acceleration);
            }
            if (ControllerInputPoller.instance.rightControllerPrimary2DAxis.y < -0.5f)
            {
                GorillaLocomotion.Player.Instance.bodyCollider.attachedRigidbody.AddForce(GorillaLocomotion.Player.Instance.bodyCollider.transform.forward * (Time.deltaTime * (-15f / Time.deltaTime)), ForceMode.Acceleration);
            }
        }
    }
} 

