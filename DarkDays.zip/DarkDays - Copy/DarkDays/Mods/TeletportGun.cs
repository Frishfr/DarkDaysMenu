﻿using BepInEx;
using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;

namespace StupidTemplate.Mods
{
    internal class TeletportGun
    {
        private static GameObject GunSphere;  //This is the sphere at the end of the gun 
        private static LineRenderer gunLine;  //This is the line on the gun for aiming or sm
        private static bool gunActive = false;  //This just tracks the gun to see if it's active 

        public static void TeleportGunMod()
        {
            //This activates the gun when the right controller grip is pressed
            if (ControllerInputPoller.instance.rightControllerGripFloat > 0.1f || UnityInput.Current.GetMouseButton(1))
            {
                if (!gunActive)
                {
                    ActivateGun();
                }
                UpdateGun();

                //This raycast to detect the teleportation target
                if (Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position, GorillaLocomotion.Player.Instance.rightControllerTransform.forward, out var hitInfo))
                {
                    HandleGunSphere(hitInfo);
                }
            }
            else if (gunActive)
            {
                DeactivateGun();
            }
        }

        private static void ActivateGun()
        {
            //This just creates the sphere
            GunSphere = GameObject.CreatePrimitive(PrimitiveType.Sphere);
            GunSphere.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
            GunSphere.GetComponent<Renderer>().material.shader = Shader.Find("GorillaTag/UberShader");
            GunSphere.GetComponent<Renderer>().material.color = Color.blue; //<--- fell free to change the color to anything you want for the sphere at the end of the gun 

            //This just makes the gun sphere non-collidable with the players hand
            GameObject.Destroy(GunSphere.GetComponent<BoxCollider>());
            GameObject.Destroy(GunSphere.GetComponent<Rigidbody>());
            GameObject.Destroy(GunSphere.GetComponent<Collider>());

            //This just adds a trail on the sphere for decorations 
            var trail = GunSphere.AddComponent<TrailRenderer>();
            trail.startWidth = 0.05f;
            trail.endWidth = 0.01f;
            trail.time = 0.5f;
            trail.material = new Material(Shader.Find("Sprites/Default"));
            trail.startColor = Color.cyan; //<-- fell free to change the color of the trail
            trail.endColor = Color.blue; //<-- fell free to change the color of the trail all so right here 

            //This creates a line to aim i gess
            gunLine = GunSphere.AddComponent<LineRenderer>();
            gunLine.startWidth = 0.05f;
            gunLine.endWidth = 0.05f;
            gunLine.material = new Material(Shader.Find("Sprites/Default"));
            gunLine.startColor = Color.cyan; //<-- Again feel free to change the color of the line 
            gunLine.endColor = Color.blue; //<-- Also right here feel free to change the color of the line 
            gunLine.useWorldSpace = true;

            gunActive = true;
        }

        private static void UpdateGun()
        {
            //This is for the aiming also don't really know to explain this one lol
            Transform controllerTransform = GorillaLocomotion.Player.Instance.rightControllerTransform;
            RaycastHit hit;
            Vector3 targetPosition = controllerTransform.position + controllerTransform.forward * 100f;

            if (Physics.Raycast(controllerTransform.position, controllerTransform.forward, out hit, 100f))
            {
                targetPosition = hit.point;
            }

            GunSphere.transform.position = targetPosition;

            //This updates the line renderer to show the connection
            gunLine.SetPosition(0, controllerTransform.position);
            gunLine.SetPosition(1, targetPosition);
        }

        private static void HandleGunSphere(RaycastHit hitInfo)
        {
            if (ControllerInputPoller.instance.rightControllerPrimaryButton || UnityInput.Current.GetMouseButton(0))
            {
                //This teleports the player to wherever you're aiming at 
                GorillaLocomotion.Player.Instance.transform.position = hitInfo.point;
                GameObject.Destroy(GunSphere, Time.deltaTime);
            }
        }

        private static void DeactivateGun()
        {
            if (GunSphere != null)
            {
                GameObject.Destroy(GunSphere);
                GunSphere = null;
            }
            gunActive = false;
        }
    }
}
