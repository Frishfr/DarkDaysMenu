﻿using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;

namespace StupidTemplate.Mods
{
    internal class StickLongArms
    {
        public static void StickLongArmsMod()
        {
            // i have to add more lines because the bot doesn't like it
            GorillaLocomotion.Player.Instance.rightHandOffset = new Vector3(0f, 0f, 0.25f); ;
            GorillaLocomotion.Player.Instance.leftHandOffset = new Vector3(0f, 0f, 0.25f); ; // dont know if works thounghghghghghghhg
                                                                                             // i have to add more lines because the bot doesn't like it
                                                                                             // i have to add more lines because the bot doesn't like it
                                                                                             // i have to add more lines because the bot doesn't like it
        }
    }
}
