﻿using GorillaLocomotion.Swimming;
using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;

namespace StupidTemplate.Mods
{
    internal class DisableWater
    {
        public static void DisableWaterMod()
        {
            foreach (WaterVolume lol in UnityEngine.Object.FindObjectsOfType<WaterVolume>())
            {
                GameObject v = lol.gameObject;
                v.layer = LayerMask.NameToLayer("TransparentFX");
            }
        }

    }
}
