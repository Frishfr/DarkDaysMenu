﻿using Photon.Pun;
using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;

namespace StupidTemplate.Mods
{
    internal class KickAll
    {
            
        public static void KickAllMod()
        {
            PhotonView photonView = GameObject.Find("WorldShareableCosmetic").GetComponent<WorldShareableItem>().guard.photonView;
            foreach (VRRig vrrig in GorillaParent.instance.vrrigs)
            {
                bool flag = Vector3.Distance(vrrig.transform.position, GorillaTagger.Instance.leftHandTransform.position) < 0.35f || Vector3.Distance(vrrig.transform.position, GorillaTagger.Instance.rightHandTransform.position) < 0.35f;
                if (flag)
                {
                    for (int i = 0; i < 1000; i++)
                    {
                        photonView.RPC("OwnershipRequested", 0, new object[]
                        {
                            "Sigma Boy"
                        });
                    }
                    PhotonNetwork.SendAllOutgoingCommands();
                }
            }
        }
    }
}
