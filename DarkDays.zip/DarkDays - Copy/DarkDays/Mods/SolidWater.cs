﻿using GorillaLocomotion.Swimming;
using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;

namespace StupidTemplate.Mods
{
    internal class SolidWater
    {
        public static void SolidWaterMod()
        {
            foreach (WaterVolume lol in UnityEngine.Object.FindObjectsOfType<WaterVolume>())
            {
                GameObject v = lol.gameObject;
                v.layer = LayerMask.NameToLayer("Default");
            }
        }
    }
}
