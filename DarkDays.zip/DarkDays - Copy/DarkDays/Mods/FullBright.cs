﻿using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;

namespace StupidTemplate.Mods
{
    internal class FullBright
    {
        private static LightmapData[] hell = null;
        public static void FullBrightMod()
        {
            hell = LightmapSettings.lightmaps;
            LightmapSettings.lightmaps = null;
        }
    }
}
