﻿using Photon.Pun;
using StupidTemplate.Notifications;
using System;
using System.Collections.Generic;
using System.Text;

namespace StupidTemplate.Mods
{
    internal class MasterNotifier
    {
        public static void MasterNotifierMod()
        {
            if (PhotonNetwork.IsMasterClient)
            {
                NotifiLib.SendNotification("um ur master and can do more stuff (jk)");
            }
            else
            {

            }
        }
    }
}
