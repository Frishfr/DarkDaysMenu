﻿using GorillaNetworking;
using Photon.Pun;
using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;

namespace StupidTemplate.Mods
{
    internal class NoName
    {
         
        public static void NoNameMod()
        {
            PhotonNetwork.LocalPlayer.NickName = "";
            GorillaComputer.instance.currentName = "";
            GorillaComputer.instance.savedName = "";
            PlayerPrefs.SetString("GorillaLocomotion.PlayerName", "");
        }
    }
}

