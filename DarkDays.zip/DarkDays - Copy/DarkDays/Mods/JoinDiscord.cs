﻿using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;
using UnityEngine.UI;

namespace StupidTemplate.Mods
{
    internal class JoinDiscord
    {
        void OpenDiscordInvite()
        {
            Application.OpenURL("https://discord.gg/P4WkKW3Bh3");
        }
    }

}

