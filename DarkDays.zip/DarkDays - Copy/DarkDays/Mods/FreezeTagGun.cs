﻿using BepInEx;
using GorillaGameModes;
using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine.InputSystem;
using UnityEngine;

namespace StupidTemplate.Mods
{
    internal class FreezeTagGun
    {
        public static void FreezeTagGunMod()
        {
            if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.1f || UnityInput.Current.GetMouseButton(1))
            {
                if (Physics.Raycast(GorillaLocomotion.Player.Instance.rightControllerTransform.position, -GorillaLocomotion.Player.Instance.rightControllerTransform.up, out var hitinfo))
                {
                    if (Mouse.current.rightButton.isPressed)
                    {
                        Camera cam = GameObject.Find("Shoulder Camera").GetComponent<Camera>();
                        Ray ray = cam.ScreenPointToRay(Mouse.current.position.ReadValue());
                        Physics.Raycast(ray, out hitinfo, 100);
                    }

                    GunSphere = GameObject.CreatePrimitive(PrimitiveType.Sphere);
                    GunSphere.transform.position = hitinfo.point;
                    GunSphere.transform.localScale = new Vector3(0.1f, 0.1f, 0.1f);
                    GunSphere.GetComponent<Renderer>().material.shader = Shader.Find("GorillaTag/UberShader");
                    GunSphere.GetComponent<Renderer>().material.color = Color.white;
                    GameObject.Destroy(GunSphere.GetComponent<BoxCollider>());
                    GameObject.Destroy(GunSphere.GetComponent<Rigidbody>());
                    GameObject.Destroy(GunSphere.GetComponent<Collider>());

                    VRRig player = hitinfo.collider.GetComponent<VRRig>();

                    if (player != null)
                    {
                        if (ControllerInputPoller.instance.rightControllerIndexFloat > 0.1f || UnityInput.Current.GetMouseButton(0))
                        {
                            GameObject.Destroy(GunSphere, Time.deltaTime);
                            GunSphere.GetComponent<Renderer>().material.color = GorillaTagger.Instance.offlineVRRig.playerColor;
                            if (GameMode.ActiveGameMode.GameType() == GameModeType.FreezeTag)
                            {
                                GorillaTagger.Instance.offlineVRRig.enabled = false;

                                GorillaTagger.Instance.offlineVRRig.transform.position = player.transform.position;
                                GorillaTagger.Instance.offlineVRRig.leftHand.rigTarget.transform.position = player.transform.position;
                                GorillaTagger.Instance.offlineVRRig.rightHand.rigTarget.transform.position = player.transform.position;

                                GorillaLocomotion.Player.Instance.rightControllerTransform.position = player.transform.position;
                            }
                        }
                        else
                        {
                            GorillaTagger.Instance.offlineVRRig.enabled = true;
                        }
                    }
                    else
                    {
                        GorillaTagger.Instance.offlineVRRig.enabled = true;
                    }
                }
            }
            if (GunSphere != null)
            {
                GameObject.Destroy(GunSphere, Time.deltaTime);
            }
        }
        private static GameObject GunSphere;
    }
}
