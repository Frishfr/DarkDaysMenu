﻿using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;

namespace StupidTemplate.Mods
{
    internal class Poo
    {
        public static void PooMod()
        {
            if (ControllerInputPoller.instance.rightGrab)
            {
                int proj = -1433634409; // projectile hash code
                int trail = -1; // projectile trail hash code / set to -1 if you dont want a trail

                var col = Color.red; // color of projectile
                Vector3 pos = GorillaLocomotion.Player.Instance.bodyCollider.transform.position; // spawn position of projectile
                Vector3 vel = GorillaLocomotion.Player.Instance.bodyCollider.transform.forward * -8.33f;
                LaunchProjectile(proj, trail, pos, vel, col);
            }
        }

        public static void LaunchProjectile(int projHash, int trailHash, Vector3 pos, Vector3 vel, Color col)
        {
            var projectile = ObjectPools.instance.Instantiate(projHash).GetComponent<SlingshotProjectile>();
            if (trailHash != -1)
            {
                var trail = ObjectPools.instance.Instantiate(trailHash).GetComponent<SlingshotProjectileTrail>();
                trail.AttachTrail(projectile.gameObject, false, false);
            }
            var counter = 0;
            projectile.Launch(pos, vel, NetworkSystem.Instance.LocalPlayer, false, false, counter++, 1, true, col);
        }
    }
}
