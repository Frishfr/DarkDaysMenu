﻿using System;
using System.Collections.Generic;
using System.Text;
using UnityEngine;

namespace StupidTemplate.Mods
{
    internal class BetaFireProjectile
    {
        public static void BetaFireProjectileMod(string projectileName, Vector3 position, Vector3 velocity, Color color, bool noDelay = false)
        {
            {
                Vector3 startpos = position;
                Vector3 charvel = velocity;

                Vector3 oldVel = GorillaTagger.Instance.GetComponent<Rigidbody>().velocity;
                GorillaTagger.Instance.GetComponent<Rigidbody>().velocity = charvel;
                SnowballThrowable fart = GameObject.Find("Player Objects/Local VRRig/Local Gorilla Player/rig/body/shoulder.R/upper_arm.R/forearm.R/hand.R/palm.01.R/TransferrableItemRightHand/SnowballRightAnchor").transform.Find("LMACF.").GetComponent<SnowballThrowable>();
                Vector3 oldPos = fart.transform.position;
                fart.randomizeColor = true;
                GorillaTagger.Instance.offlineVRRig.SetThrowableProjectileColor(false, color);
                fart.transform.position = startpos;
                fart.projectilePrefab.tag = projectileName;
                fart.OnRelease(null, null);
                try
                {
                    // RPCProtection();
                }
                catch { /*wtf*/ }
                GorillaTagger.Instance.GetComponent<Rigidbody>().velocity = oldVel;
                fart.transform.position = oldPos;
                fart.randomizeColor = false;
                fart.projectilePrefab.tag = "SnowballProjectile";
                {
                }
            }
        }
    }
}
