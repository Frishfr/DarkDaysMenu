﻿using GorillaNetworking;
using System;
using System.Collections.Generic;
using System.Text;

namespace StupidTemplate.Mods
{
    internal class JoinRoom
    {
        public static void JoinRoomMod(string Frish)
        {
            PhotonNetworkController.Instance.AttemptToJoinSpecificRoom(Frish, JoinType.Solo);
        }
    }
}