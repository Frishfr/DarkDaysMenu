﻿namespace StupidTemplate
{
    internal class PluginInfo
    {
        public const string GUID = "org.Frishy.gorillatag.DarkDays";
        public const string Name = "DarkDays";
        public const string Description = "Made By FrishGT With The Stupid Template";
        public const string Version = "1.1.1";
    }
}
